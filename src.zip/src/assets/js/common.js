export default{
  install (Vue, options) {
    Vue.prototype.httpUrlRSS = 'http://192.168.1.197/'
    Vue.prototype.httpUrlWMK = 'http://192.168.1.184/'
    Vue.prototype.httpUrlSS = 'http://192.168.1.197/'
    Vue.prototype.httpUrlMK = 'http://192.168.1.184/'
  }
}
