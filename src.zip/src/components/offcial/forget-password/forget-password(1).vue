<template>
  <div class="container container-workorder-category">
    <div class="router-view inner-page">
      <div class="console-box">
        <div class="p20">
          <!-- 头部步骤条 -->
          <div class="t-progress">
            <div class="step is-active">
              <div class="num-tab">1</div>
              <div class="num-line"></div>
              <div class="p-txt">输入用户名</div>
              <div class="p-desc"></div>
            </div>
          </div>
          <!-- 内容文字 -->
          <div class="forget-container"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {}
}
</script>

<style>
*{outline: none;}
.container, .router-view{
  position: absolute;
  min-width: 80rem;
}
.container{
  width:100%;
  top:7rem;
  left:0;
  bottom: 0;
  background:#e8ecef;
  transform: none;
  transition: none;
  height:auto;
  overflow: hidden;
  z-index: 99;
}
.router-view.inner-page{
  margin:0;
  top:.625rem;
  left:.625rem;
  right:.625rem;
  bottom: .625rem;
}
.router-view{
  width:calc(100% -20px);
  background-color:#ffffff;
  overflow-y: auto;
  overflow-x: hidden;
}
.console-box{
  padding:1.25rem;
  margin:0;
  background-color:#ffffff;
  box-sizing: border-box;
}
.p20{
  padding:1.25rem;
}
.t-progress{
  display: flex;
  width:100%;
  margin:.625rem 0 1.25rem;
  padding-top:1.875rem;
}
.forget-container{
  width:60%;
  margin:3.75rem auto 0;
}
.t-progress .step{
  position:relative;
  -webkit-box-flex: 1;
  flex:1;
}
.t-progress .is-active .num-tab, .t-progress .is-active .num-line{
  background:#02004B;
}
.t-progress .step .num-tab{
  width:.9375rem;
  height:.9375rem;
  line-height: .9375rem;
  border-radius: 50%;
  position: absolute;
  left:50%;
  top:0%;
  margin:0 0 0 -8px;
  z-index: 2;
  font-size: .75rem;
  text-align: center;
  color:#fff;
}
.t-progress .step .num-line {
  position:absolute;
  top: .3125rem;
  width:100%;
  height:3px;
}
</style>
