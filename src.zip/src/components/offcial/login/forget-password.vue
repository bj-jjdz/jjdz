<template>
  <div class="container">
    <!-- 头部 -->
    <el-steps :active="active" align-center finish-status="success">
      <el-step title="输入用户名"></el-step>
      <el-step title="重置密码"></el-step>
      <el-step title="完成"></el-step>
    </el-steps>
    <div class="BgImg"></div>
    <!-- 输入用户名的时候(active==0) -->
    <div v-if="this.active==0" class="formTabel" ref='ruleForm'>
      <el-form :model="form" ref="form" label-width="130px">
        <el-form-item label="请输入账户名:" prop="name">
          <el-input v-model="form.name"></el-input>
        </el-form-item>
        <el-form-item label="请输入短信验证:">
          <el-input v-model="form.SMSVFtion" class="MyInput">
            <el-button slot="append" class="FSyanzhen">发送验证</el-button>
          </el-input>
        </el-form-item>
        <el-form-item class="formBtn">
          <el-button type="primary" @click="next">下一步</el-button>
        </el-form-item>
      </el-form>
    </div>
    <!-- 重置密码的时候(active==1) -->
    <div v-else-if="this.active==1" class="formTabel">
      <el-form :model='ruleForm' :rules='rules' ref='ruleForm' label-width='100px' class='demo-ruleForm'>
        <el-form-item label='设置密码' prop='pass'>
          <el-input type='password' v-model='ruleForm.pass' autocomplete='off' placeholder='建议使用至少两种字符组合' show-password></el-input>
        </el-form-item>
        <el-form-item label='确认密码' prop='checkPass'>
          <el-input type='password' v-model='ruleForm.checkPass' autocomplete='off' placeholder='请再次输入密码' show-password></el-input>
        </el-form-item>
      </el-form>
    </div>
    <!-- 完成的时候(active==2) -->
    <div v-else-if="this.active==2" class="formTabel">
      <div class="Success">
        <span class="SuccessIcon"></span>
        <p class="successText">重置成功，请牢记新的密码！</p>
        <el-button type="primary">
          <router-link to='/loginUp' class="login_in_img">前往登陆</router-link>
        </el-button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else {
        if (this.ruleForm.checkPass !== '') {
          this.$refs.ruleForm.validateField('checkPass')
        }
        callback()
      }
    }
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.ruleForm.pass) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      active: 0,
      form: {
        name: '',
        SMSVFtion: ''
      },
      ruleForm: {
        pass: '',
        checkPass: ''
      },
      rules: {
        pass: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { validator: validatePass, trigger: 'blur' }
        ],
        checkPass: [
          { required: true, message: '请再次输入密码', trigger: 'blur' },
          { validator: validatePass2, trigger: 'blur' }
        ]
      }
    }
  },
  mounted () {

  },
  methods: {
    next () {
      if (this.active++ > 2) this.active = 0
      this.mounted()
    },
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert('submit!')
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
  }
}
</script>

<style>
*{outline: none;}
.colorRad{
  color:#ff0000;
}
.container, .router-view{
  position: absolute;
  min-width: 80rem;
}
.container{
  width:100%;
  top:7rem;
  left:0;
  bottom: 0;
  background:#e8ecef;
  height:auto;
  overflow: hidden;
  z-index: 99;
  padding-top:3rem;
}
.container .formTabel{
  position: relative;
  bottom:80%;
}
.container .BgImg{
  width:32.4375rem;
  height:37.0625rem;
  position: relative;
  left:39%;
  background-image: url('../../../assets/img/login-inup/logo_gray.png');
  background-size: 70% 70%;
  background-repeat: no-repeat;
}
.container .el-input__inner{
  background-color:#f8f8f8;
  border-radius: .625rem;
  border:1px solid #dedede;
}
.container .el-form{
  width:50%;
  margin:0 auto;
  margin-top:5rem;
}
.container .el-form-item__label{
  font-family: PingFang-SC-Medium;
  font-weight: normal;
  font-stretch: normal;
  color:#666666;
  font-size:.875rem;
  letter-spacing: 0px;
}
.container .formBtn{
  margin-top:2rem;
  text-align: left;
}
.container .el-button--primary{
  background-color: #02004b;
  border-radius: .625rem;
  width:96px;
  height:50px;
}
.container .el-form-item__label::before{
  content: '*';
  color:#f56c6c;
  margin-right:4px;
}
.container .Success{
  margin-top:5rem;
  position: relative;
}
.container .Success .successText{
  margin-bottom: 1rem;
}
.container .Success .successText:before{
  content: '';
  position: absolute;
  left:43%;
}
.container .Success .successText::before{
  width:42px;
  height:42px;
  background-image: url('../../../assets/img/login-inup/success.png');
  background-repeat: no-repeat;
  background-size:50% 50%;
}
.container .MyInput input{
  border-top-right-radius: 0px !important;
  border-bottom-right-radius: 0px !important;
  border-right:0 !important;
}
.container .MyInput .FSyanzhen{
  /* border-top-right-radius: .625rem;
  border-bottom-right-radius: .625rem; */
  border:1px solid .625rem !important;
}
</style>
