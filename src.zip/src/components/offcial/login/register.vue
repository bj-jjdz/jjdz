<template>
  <div class='register'>
    <el-row :gutter='20' class='registerTop'>
      <el-col :span='8' :offset='8'><div class='titleLeft'>注册九江东注会员账号</div></el-col>
      <el-col :span='4' :offset='4'><div class='titleRight'>已有账户，去<span class='loginIn' style='color:#02004b'>登录</span></div></el-col>
    </el-row>
    <div class='registerBottom'>
      <el-form :model='ruleForm' :rules='rules' ref='ruleForm' label-width='100px' class='demo-ruleForm'>
        <el-form-item label='手机号码' prop='age'>
          <el-input v-model.number='ruleForm.mobile' placeholder='手机号作为登录账号' maxlength='13'></el-input>
        </el-form-item>
        <el-form-item label='设置密码' prop='pass'>
          <el-input type='password' v-model='ruleForm.pass' autocomplete='off' placeholder='建议使用至少两种字符组合' show-password></el-input>
        </el-form-item>
        <el-form-item label='确认密码' prop='checkPass'>
          <el-input type='password' v-model='ruleForm.checkPass' autocomplete='off' placeholder='请再次输入密码' show-password></el-input>
        </el-form-item>
        <el-form-item>
          <div class="slider">
            <span style="position: absolute;left:35%;top:28%;z-index:1000">滚动滑块验证</span>
            <el-slider v-model="sliderText" :show-tooltip="false" @change='sliderBtn'></el-slider>
          </div>
        </el-form-item>
        <el-form-item>
        <!-- `checked` 为 true 或 false -->
          <el-checkbox v-model='checked'>阅读并接受<span style='color:#02004b'>《九江东注网站服务协议》</span></el-checkbox>
        </el-form-item>
        <el-form-item>
          <el-button type='primary' class='nowRegister' @click=submitForm()>立即注册</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
import qs from 'qs'
export default {
  data () {
    var checkAge = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('手机号不能为空'))
      }
      setTimeout(() => {
        if (!Number.isInteger(value)) {
          callback(new Error('请输入数字'))
        } else if (!(/^1(3|4|5|7|8)\d{9}$/.test(value))) {
          callback(new Error('请输入正确手机号'))
        } else if (value.lenght > 13) {
          callback(new Error('请输入正确手机号'))
        }
      }, 500)
    }
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else {
        if (this.ruleForm.checkPass !== '') {
          this.$refs.ruleForm.validateField('checkPass')
        }
        callback()
      }
    }
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.ruleForm.pass) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      ruleForm: {
        pass: '',
        checkPass: '',
        mobile: ''
      },
      rules: {
        pass: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { validator: validatePass, trigger: 'blur' }
        ],
        checkPass: [
          { required: true, message: '请再次输入密码', trigger: 'blur' },
          { validator: validatePass2, trigger: 'blur' }
        ],
        age: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          { validator: checkAge, trigger: 'blur' }
        ]
      },
      checked: false,
      // 是否通过验证的标志
      success: false,
      distance: '',
      sliderText: ''
    }
  },
  mounted () {
    console.log('进度', this.sliderText)
  },
  methods: {
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert('submit!')
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    resetForm (formName) {
      this.$refs[formName].resetFields()
    },
    sliderBtn () {
      console.log(this.sliderText, '555')
      if (this.ruleForm.mobile === '' || this.ruleForm.pass || this.ruleForm.checkPass) {
        this.$message.Error({message: '注意：有未填项'})
      }
      if (this.sliderText > 90) {
        this.$message({
          type: 'success',
          message: '验证成功!'
        })
        let that = this
        console.log('======', that.ruleForm)
        let mobile = that.ruleForm.mobile
        that.$axios.post(this.httpUrlRSS + 'jiujiangdongzhu/Home/Register/register_duanxin', qs.stringify({mobile: mobile})).then(function (res) {
          console.log('666666', res)
        })
      } else if (this.sliderText < 100) {
        this.$message({
          type: 'info',
          message: '请重试!'
        })
      }
    }
  }
}
</script>
<style scoped>
.register{
  width: 100%;
  height: 40.1rem;
  box-sizing: border-box;
  background-color: #fff;
  background-image:url(../../../assets/img/login-inup/logo_gray.png);
  background-repeat: no-repeat;
  background-position: center;
  background-position-y: 10%;
  padding: 4rem 23rem 4rem 23rem;
}
.registerTop{
  box-sizing: border-box;
  padding-bottom: 2rem;
  border-bottom: #d7d7d7 1px solid;
}
.registerTop .titleLeft{
  font-size: 1.75rem;
  color: #333333;
}
.registerTop .titleRight{
  font-size: 1rem;
  color: #333333;
  text-align: center;
  margin-top: 0.6rem;
}
.loginIn:hover{
  cursor: pointer;
}
.registerBottom{
  box-sizing: border-box;
  padding: 4rem 23rem 0rem 22rem;
}
.registerBottom .nowRegister{
  width: 18rem;
  height: 3rem;
  background-color: #ff0000;
  border-radius: 10px;
  border: none;
}
/* 滑块 */
.registerBottom .drag{
    width: 300px;
    height: 40px;
    line-height: 40px;
    background-color: #e8e8e8;
    position: relative;
    margin:0 auto;
}
.registerBottom .bg{
    width:40px;
    height: 100%;
    position: absolute;
    background-color: #75CDF9;
}
.registerBottom .text{
    position: absolute;
    width: 100%;
    height: 100%;
    text-align: center;
    user-select: none;
}
.registerBottom .btn{
    width:40px;
    height: 38px;
    position: absolute;
    border:1px solid #ccc;
    cursor: move;
    font-family: '宋体';
    text-align: center;
    background-color: #fff;
    user-select: none;
    color:#666;
}
/* 以上可以删除 */
.slider{
  position: relative;
}
</style>
<style>
.registerBottom .el-input__inner{
  background-color: #f8f8f8;
}
.registerBottom .el-slider__runway{
  width: 19rem;
  height: 3rem;
  box-sizing: border-box;
  background-color: #d9d9d9;
}
.registerBottom  .el-slider__bar{
  width: 19rem;
  height: 3rem;
  background-color: #d9d9d9;
}
.registerBottom .el-slider__button-wrapper{
  width: 3rem;
  height: 3rem;
  box-sizing: border-box;
  background-color: #fff;
  border-radius: 0rem 0rem 0rem 0rem;
  border: solid 0.1rem #d2d2d2;
  top: 0rem;
  left: 0;
}
.registerBottom .el-slider__button{
  width: 0px;
  height: 0px;
  border-radius: 0;
  color: #333;
  background: transparent;
  border-top: 0.6rem solid transparent;
  border-right: 0.6rem solid transparent;
  border-bottom: 0.6rem solid transparent;
  border-left: 0.8rem solid #333;
  margin-left: 1rem;
  /* content: "\e613" */
}
</style>
