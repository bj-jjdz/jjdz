const getters = {
  // getCount: state => state.count,
}

export default getters
