const state = {
  showLeftMenu: true,
  globalLoading: true,
  menus: [],
  rules: [],
  users: {},
  userGroups: [],
  organizes: []
}

export default state
